from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    balanced_accuracy_score,
    confusion_matrix,
    classification_report
)

from dataset_preprocessing import load_awid_data, preprocess_awid_data


def train_decision_tree(X_train, y_train):
    dt = DecisionTreeClassifier(random_state=42, max_depth=10,class_weight='balanced') # Initialize a tree that can only ask 10 questions to avoid memorizing
    dt.fit(X_train, y_train) # training step: looks at features (X) and answers (y)
    return dt


def train_random_forest(X_train, y_train):
    rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1,class_weight='balanced') # Build 100 different trees (n_estimators) and n_jobs=-1 for faster results.
    rf.fit(X_train, y_train) # training step: looks at features (X) and answers (y)
    return rf


def evaluate_model(name, model, X_test, y_test, class_names):
    y_pred = model.predict(X_test) # model looks at X_test and creates its own guesses (y_pred)

    results = { # comparing model guesses (y_pred) to real answers (y_test) , i used macro for average to treat every class as equally
        "Model": name,
        "Accuracy": accuracy_score(y_test, y_pred),
        "Precision_macro": precision_score(y_test, y_pred, average="macro",zero_division=0),
        "Recall_macro": recall_score(y_test, y_pred, average="macro",zero_division=0),
        "F1_macro": f1_score(y_test, y_pred, average="macro",zero_division=0),
        "Balanced Accuracy": balanced_accuracy_score(y_test, y_pred),
        "Classification Report": classification_report(
            y_test, y_pred, target_names=class_names,zero_division=0
        )
    }

    print(f"\n{name}")
    print(f"Accuracy: {results['Accuracy']:.4f}")
    print(f"Precision_macro: {results['Precision_macro']:.4f}")
    print(f"Recall_macro: {results['Recall_macro']:.4f}")
    print(f"F1_macro: {results['F1_macro']:.4f}")
    print(f"Balanced Accuracy: {results['Balanced Accuracy']:.4f}")
    print("\nClassification Report:\n", results["Classification Report"])

    return results, y_pred




def main():
    train_path = "dataset/AWID_CLS_R_Trn.csv" # File paths for the data
    test_path = "dataset/AWID_CLS_R_Tst.csv"
    
    # Step 1: Load the files
    train_df, test_df = load_awid_data(train_path, test_path)
    
    # Step 2: Clean, Split X and y and Map labels to numbers
    X_train, X_test, y_train, y_test, class_mapping = preprocess_awid_data(train_df, test_df)

    # Get the names (normal, flooding, etc.) for the results_visualization and report
    class_names = list(class_mapping.keys())

    # Step 3: Train and Test the Decision Tree
    dt = train_decision_tree(X_train, y_train)
    dt_results, dt_pred = evaluate_model("Decision Tree", dt, X_test, y_test, class_names)

    # Step 4: Train and Test the Random Forest
    rf = train_random_forest(X_train, y_train)
    rf_results, rf_pred = evaluate_model("Random Forest", rf, X_test, y_test, class_names)



if __name__ == "__main__":
    main()