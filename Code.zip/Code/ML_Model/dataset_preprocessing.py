import pandas as pd # Import pandas for data manipulation
import numpy as np # Import numpy for numerical operations
from sklearn.impute import SimpleImputer # Import tool to fill in missing data values


def load_awid_data(train_path, test_path): 
    train_df = pd.read_csv(train_path, header=None, low_memory=False, dtype=str) # Load training CSV; no header, load everything as string.
    test_df = pd.read_csv(test_path, header=None, low_memory=False, dtype=str) # Load testing CSV; no header, load everything as string.

    train_df = train_df.rename(columns={train_df.columns[-1]: "label"}) # AWID labels are in the last column; rename that column to "label"
    test_df = test_df.rename(columns={test_df.columns[-1]: "label"})

    return train_df, test_df


def preprocess_awid_data(train_df, test_df):
    """
    Preprocessing using original AWID labels:
    normal, injection, impersonation, flooding
    """

    class_mapping = { # convert text labels into numeric integers
        "normal": 0,
        "injection": 1,
        "impersonation": 2,
        "flooding": 3
    }

    # Create target and map the text labels in the "label" column to the integers defined above
    train_df["target"] = train_df["label"].map(class_mapping)
    test_df["target"] = test_df["label"].map(class_mapping)

    # Drop label/target to isolate features and replace AWID specific missing markers ("-", "?") with NaN
    X_train = train_df.drop(columns=["label", "target"]).replace(["-", "?"], np.nan)
    X_test = test_df.drop(columns=["label", "target"]).replace(["-", "?"], np.nan)

    # Convert to numeric, values that can't be converted become NaN
    X_train = X_train.apply(pd.to_numeric, errors="coerce")
    X_test = X_test.apply(pd.to_numeric, errors="coerce")

    # Remove empty columns
    valid_columns = X_train.columns[X_train.notna().any()]
    X_train = X_train[valid_columns]
    X_test = X_test[valid_columns]

    # Targets 
    y_train = train_df["target"]
    y_test = test_df["target"]

     # Initialize imputer to replace all remaining NaNs with a constant value of -1
    imputer = SimpleImputer(strategy="constant", fill_value=-1)
    X_train = imputer.fit_transform(X_train) # Fit imputer on training data and transform it into a clean array
    X_test = imputer.transform(X_test) # Applying same for testing data

    return X_train, X_test, y_train, y_test, class_mapping